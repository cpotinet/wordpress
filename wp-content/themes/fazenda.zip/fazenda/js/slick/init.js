// JavaScript Document
$('.slider').slick();